#!/usr/bin/env python3
import smtplib 
from email import encoders 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email.mime.image import MIMEImage
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.multipart import MIMEMultipart
import argparse

sender = 'keke.zou@unimeddx.com'
passWord = 'FUY6GNGE7jC34REQ'
mail_host = 'smtp.exmail.qq.com'

def get_par():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s","--subject",help="mail subject",default="无")
    parser.add_argument("-t","--to",help="receiver",required=True)
    parser.add_argument("--images",help="sended images",default=None)
    parser.add_argument("--attachs",help="attachments",default=None)
    parser.add_argument("--sender",help="sender",default=sender)
    #parser.add_argument("-c","--copy",help="copy to",default=None)
    parser.add_argument("--content",help="mail content. If 'content' string exist and the '-f' will be ignored.",default=None)
    parser.add_argument("-f",'--file',help="content file",dest='FILE')
    parser.add_argument("--password",help="sender password",default=passWord)
    parser.add_argument("--mailhost",help="sender mail host",default=mail_host)
    args = parser.parse_args()
    #print(args)
    return args

def parse_send_header():
    from email.parser import Parser
    headers = Parser().parsestr('From: <user@example.com>\n'
        'To: <someone_else@example.com>\n'
        'Subject: Test message\n'
        '\n'
        'Body would go here\n')
    print('To: %s' % headers['to'])
    print('From: %s' % headers['from'])
    print('Subject: %s' % headers['subject'])

def pic_fuc(image):
    with open(image,'rb') as fp:
        img = fp.read()
    return img

def get_content(par):
    msg_content = par.content
    if not msg_content:
        f = open(par.FILE,'rb')
        msg_content = f.read()
        f.close()
    return msg_content

def main():
    par = get_par()
    msg = MIMEMultipart()
    msg['Subject'] = par.subject
    msg['From'] = par.sender
    msg['To'] = par.to
    #if par.copy:
    #    msg['Cc'] = par.copy
    
    #add content
    msg_content = get_content(par)
    msg.attach(MIMEText(msg_content,'plain','utf-8'))

    #add picture
    if par.images:
        images = par.images.split(',')
        for image in images:
            img = pic_fuc(image)
            msg.attach(MIMEImage(img))

    #add attachment
    if par.attachs:
        attachs = par.attachs.split(',')
        for attach in attachs:
            att = MIMEText(open(attach,'rb').read(),'base64','utf-8')
            att["Content-Type"] = 'application/octet-stream'
            att["Content-Disposition"] = 'attachment; filename="{f}"'.format(f=attach)
            msg.attach(att)

    #send email
    receviers = par.to.split(',')
    for recevier in receviers:
        try:    
            #QQsmtp服务器的端口号为465或587    
            s = smtplib.SMTP_SSL(par.mailhost, 465)   
            s.set_debuglevel(1)    
            s.login(par.sender,par.password)
            #给receivers列表中的联系人逐个发送邮件    
            s.sendmail(par.sender,recevier,msg.as_string())
            print ("All emails have been sent over!")
        except smtplib.SMTPException as e:    
            print ("Falied,%s",e)


def for_learning():
        sender = 'keke.zou@unimeddx.com'
        passWord = 'FUY6GNGE7jC34REQ'          #服务器授权码
        mail_host = 'smtp.exmail.qq.com'
        receivers = ['511897040@qq.com','zoukeke163@163.com']

        msg = MIMEMultipart()
        msg['Subject'] = '哈哈哈哈' #input(f"{'请输入邮件主题:'}") #邮件主题
        msg['From'] = sender #发送方信息
        msg_content = '自动发邮件测试' #input(f"{'请输入邮件正文:'}") #邮件正文
        #附件
        msg.attach(MIMEText(msg_content,'plain','utf-8'))
        with open('/home/keke.zou/bin/send_email/L171128-A1.cnv.png','rb') as f:
            #设置附件的MIME和文件名，这里是png类型，可以转化成jpg或其他类型
            mime = MIMEBase('image','png',filename='pig.jpg')
            #加上必要的头信息
            mime.add_header('Content-Disposition', 'attachment', filename='test.png')    
            mime.add_header('Content-ID', '<0>')    
            mime.add_header('X-Attachment-Id', '0')    
            # 把附件的内容读进来:    
            mime.set_payload(f.read())    
            # 用Base64编码:    
            encoders.encode_base64(mime)    
            # 添加到MIMEMultipart:    
            msg.attach(mime)

            #登录并发送邮件
        try:    
            #QQsmtp服务器的端口号为465或587    
            s = smtplib.SMTP_SSL(mail_host, 465)    
            s.set_debuglevel(1)    
            s.login(sender,passWord)    
            #给receivers列表中的联系人逐个发送邮件    
            for i in range(len(receivers)):        
                to = receivers[i]       
                msg['To'] = to        
                s.sendmail(sender,to,msg.as_string())        
                print('Success!')    
            s.quit()    
            print ("All emails have been sent over!")
        except smtplib.SMTPException as e:    
            print ("Falied,%s",e)

if __name__ == "__main__":
    main()
